#!/usr/bin/env bash

# Vor/Nach Signalen nur Kinder des Sighandlers zählen
SIGH=$(pgrep -n -f 'lemonbar/sighandler.sh')
pgrep -P "$SIGH" -x sleep | wc -l

# Signale auslösen (an deine SIGRTMIN+N anpassen)
kill -SIGRTMIN+4 "$SIGH"   # Uhr
kill -SIGRTMIN+3 "$SIGH"   # CPU
